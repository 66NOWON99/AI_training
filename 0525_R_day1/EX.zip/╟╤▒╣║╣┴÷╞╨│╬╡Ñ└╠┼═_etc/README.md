#### 아래 링크를 클릭해 한국복지패널데이터 관련 자료를 다운로드하세요.

[Koweps_etc.zip](http://bit.ly/Koweps_etc)
