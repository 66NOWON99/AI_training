#### 아래 링크를 클릭해 한국복지패널데이터 파일을 다운로드하세요.

[Koweps_hpc10_2015_beta1.sav](http://bit.ly/Koweps_hpc10_2015_v2)   
