
# coding: utf-8

# In[11]:


from selenium import webdriver
from selenium.webdriver.support.ui import Select


# In[2]:


driver = webdriver.Chrome('chromedriver')
driver.get('https://www.naver.com')


# In[3]:


a_tag = driver.find_element_by_css_selector('#account > div > div > a')
# print(a_tag)
a_tag.click()


# In[4]:


checkbox_tag = driver.find_element_by_css_selector('#join_form > div.terms_p > p > span > label')
checkbox_tag.click()

agree_btn = driver.find_element_by_css_selector('#btnAgree')
agree_btn.click()


# In[13]:


driver.refresh()

input_id = driver.find_element_by_css_selector('#id')
input_id.send_keys('opiwejrojwpo')

input_pswd1 = driver.find_element_by_css_selector('#pswd1')
input_pswd1.send_keys('Abc123zzz!!')

input_pswd2 = driver.find_element_by_css_selector('#pswd2')
input_pswd2.send_keys('Abc123zzz!!')

input_name = driver.find_element_by_css_selector('#name')
input_name.send_keys('윤재성')

input_yy = driver.find_element_by_css_selector('#yy')
input_yy.send_keys('1978')

input_mm = driver.find_element_by_css_selector('#mm')
select_tag = Select(input_mm)
select_tag.select_by_value('12')

input_dd = driver.find_element_by_css_selector('#dd')
input_dd.send_keys('17')

input_gender = driver.find_element_by_css_selector('#gender')
select_tag2 = Select(input_gender)
select_tag2.select_by_value('0')

input_phoneNo = driver.find_element_by_css_selector('#phoneNo')
input_phoneNo.send_keys('01043950924')

btn_send = driver.find_element_by_css_selector('#btnSend')
btn_send.click()

sms_code = input('인증번호를 입력해주세요')

auth_no = driver.find_element_by_css_selector('#authNo')
auth_no.send_keys(sms_code)

btn_join = driver.find_element_by_css_selector('#btnJoin')
btn_join.click()

